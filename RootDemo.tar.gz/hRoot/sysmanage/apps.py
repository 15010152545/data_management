from django.apps import AppConfig


class SysmanageConfig(AppConfig):
    name = 'sysmanage'
