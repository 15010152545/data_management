from django.apps import AppConfig


class LoginmanageConfig(AppConfig):
    name = 'loginmanage'
